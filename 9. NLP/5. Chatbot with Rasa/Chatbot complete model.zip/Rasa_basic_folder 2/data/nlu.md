## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- thanks
- thank you
- yes. Please

## intent:deny
- no
- Nope
- Not required
- No. Thats okay
- False

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- Hola

## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in the [New Delhi]{"entity": "location", "value": "Delhi"}
- show me a [mexican](cuisine) place in the [centre](location)
- i am looking for an [indian](cuisine) spot called olaolaolaolaolaola
- search for restaurants
- anywhere in the [west](location)
- I am looking for [asian fusion](cuisine) food
- I am looking a restaurant in [294328](location)
- in [Gurgaon](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- [chinese](cuisine)
- [Lithuania](location)
- Oh, sorry, in [Italy](location)
- in [delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [mexican indian fusion](cuisine)
- [central](location) [indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- Please find me a restaurantin [bangalore](location)
- [mumbai](location)
- show me restaurants
- [chinese](cuisine) restaurant in [300](budgetMin)-[700]{"entity": "budgetMax", "value": "Rs. 300 to 700"} range in [delhi](location) in [rome](location)
- [300](budgetMin)-[700]{"entity": "budgetMax", "value": "Rs. 300 to 700"} range [chinese](cuisine) restaurant
- [<300]{"entity": "budgetMax", "value": "300"}
- [>700]{"entity": "budgetMin", "value": "700"}
- [300](budgetMin)-[700]{"entity": "budgetMax", "value": "Rs. 300 to 700"} range
- please find me [chinese](cuisine) restaurant in [delhi](location)
- can you find me a [chinese](cuisine) restaurant
- [delhi](location)
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore](location)
- find me a [chinese](cuisine) restaurant in [rome](location)
- find me a restaurant in [chinese](cuisine) restaurant in [tokyo](location)
- can you please find me a [italian](cuisine) restaurant in [mumbai](location)
- more than [700] {"entity": "budgetMax", "value": "700"}
- Rs. [300](budgetMin) to [700](budgetMax)
- Lesser than Rs. [300](budgetMax)
- [Gurgaon](location)
- [chinese](cuisine) restaurant in [tokyo](location)
- find me [chinese](cuisine) food priced below [200](budgetMax)
- find me food priced between [200](budgetMin) and [400](budgetMax)
- [Noida](location)
- [chinese](cuisine) restaurant in [noida](location)
- yes. Please send it to [ahbcdj@dkj.com](mail_id)
- [asdasdas@gmail.com](mail_id)
- find me restaurant in [bengaluru]{"entity": "location", "value": "bangalore"}
- find me a [italian](cuisine) restaurant in [noida](location)
- [Bangalore](location)
- I’m hungry. Looking out for some good restaurants
- [Bengaluru]{"entity": "location", "value": "bangalore"}
- [bengaluru]{"entity": "location", "value": "bangalore"}
- find restaurant in [Noida](location)
- find [chinese](cuisine) restaurant in [bangalore](location)
- [sestajespo@biyac.com](mail_id)
- restaurant in [bengaluru]{"entity": "location", "value": "bangalore"}
- /restaurant_search{"budgetMin":300,"budgetMax":700}
- [anything@gmail.com](mail_id)
- [test@upgrad.com](mail_id)

## synonym:300
- <300

## synonym:700
- >700

## synonym:Delhi
- New Delhi

## synonym:Rs. 300 to 700
- 700

## synonym:bangalore
- bengaluru
- Bengaluru

## synonym:chinese
- chines
- Chinese
- Chines

## synonym:mid
- moderate

## synonym:vegetarian
- veggie
- vegg

## regex:greet
- hey[^\s]*

## regex:location
- [^\s]*

## regex:mail_id
- ^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$

## regex:pincode
- [0-9]{6}
