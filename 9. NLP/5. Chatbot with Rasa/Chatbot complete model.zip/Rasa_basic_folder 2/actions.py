from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import pandas as pd
import json
from rasa_sdk.events import FollowupAction
import smtplib, ssl
import email.message

mailaddress = 'chatbotupgrad2@gmail.com'
mailpassword = 'Lu@i8VkRNrJ3qrP'

ZomatoData = pd.read_csv('zomato.csv')
ZomatoData = ZomatoData.drop_duplicates().reset_index(drop=True)
WeOperate = ['Delhi', 'Gurgaon', 'Noida', 'Faridabad', 'Allahabad', 'Bhubaneshwar', 'Mangalore', 'Mumbai', 'Ranchi', 'Patna', 'Mysore', 'Aurangabad', 'Amritsar', 'Puducherry', 'Varanasi', 'Nagpur', 'Vadodara', 'Dehradun', 'Vizag', 'Agra', 'Ludhiana', 'Kanpur', 'Lucknow', 'Surat', 'Kochi', 'Indore', 'Ahmedabad', 'Coimbatore', 'Chennai', 'Guwahati', 'Jaipur', 'Hyderabad', 'Bangalore', 'Nashik', 'Pune', 'Kolkata', 'Bhopal', 'Goa', 'Chandigarh', 'Ghaziabad', 'Ooty', 'Gangtok', 'Shimla']

def RestaurantSearch(City,Cuisine):
	TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (ZomatoData['City'].apply(lambda x: City.lower() in x.lower()))]
	return TEMP[['Restaurant Name','Address','Average Cost for two','Aggregate rating','Currency']]

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'

	def run(self, dispatcher, tracker, domain):
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		budgetMax = int(tracker.get_slot('budgetMax'))
		budgetMin = int(tracker.get_slot('budgetMin'))
		results = RestaurantSearch(City=loc,Cuisine=cuisine)
		response="Showing you top rated restaurants: \n\n"
		restaurantList = []
		if results.shape[0] == 0:
			response= "No restaurant found with your search criteria"
		else:
			for restaurant in results.iterrows():
				restaurant = restaurant[1]
				if len(restaurantList)>5:
					break
				if int(restaurant['Average Cost for two'])>budgetMin and int(restaurant['Average Cost for two'])<budgetMax:
					restaurantList.append(F"{restaurant['Restaurant Name']} in {restaurant['Address']} rated {restaurant['Aggregate rating']} with average price for two people here is: {restaurant['Currency']} {restaurant['Average Cost for two']} \n\n")
		if len(restaurantList)>0:
			for index,value in enumerate(restaurantList):
				response = response + str(index+1) + ". " + value
		dispatcher.utter_message(response)
		return [SlotSet('restaurantList',restaurantList)]

class ActionSendMail(Action):
	def name(self):
		return 'action_send_mail'

	def run(self, dispatcher, tracker, domain):
		mail_address = tracker.get_slot('mail_id')
		msg = tracker.get_slot('restaurantList')
		self.sendmail(mail_address, msg)
		return [FollowupAction("utter_mail_sent")]
	
	def sendmail(self, mail_address, msg):
		try:
			server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
			server.ehlo()
			response="Showing you top rated restaurants: <br/><br/>"
			if len(msg)>0:
				for index,value in enumerate(msg):
					response = response + str(index+1) + ". " + value + "<br/>"
			email_text = email.message.Message()
			email_text['subject']='Restaurant List'
			email_text.set_payload(F"""
			{response}
			""")
			server.login(mailaddress, mailpassword)
			server.sendmail(mailaddress, mail_address, email_text.as_string())
			server.quit()
		except:
			print("Something went wrong")
		return

class checkOperatingCities(Action):
	def name(self):
		return 'check_operating_cities'

	def run(self, dispatcher, tracker, domain):
		location = tracker.get_slot('location')
		if location.upper() not in map(str.upper, WeOperate):
			return[FollowupAction("utter_ask_location_again")]
		else:
			return

class checkBudget(Action):
	def name(self):
		return 'check_budget'

	def run(self, dispatcher, tracker, domain):
		budgetMin = None
		budgetMax = None
		try:
			budgetMin = int(tracker.get_slot('budgetMin'))
			budgetMax = int(tracker.get_slot('budgetMax'))
		except ValueError:
			dispatcher.utter_message('Invalid budget given. Please enter again')
			return[FollowupAction("utter_ask_budget"), SlotSet('budgetMin', None), SlotSet('budgetMax', None)] 

		if budgetMin in [0,300,700] and (budgetMax in [300,700] or budgetMax>700):
			return
		else:
			dispatcher.utter_message('Invalid budget given. Please enter again')
			return[FollowupAction("utter_ask_budget"), SlotSet('budgetMin', None), SlotSet('budgetMax', None)]
		